//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Example.rc
//
#define IDD_DIALOG1                     101
#define IDC_BUTTON1                     1001
#define IDC_BUTTON2                     1002
#define IDC_BUTTON3                     1003
#define IDC_BUTTON4                     1004
#define IDC_BUTTON5                     1005
#define IDC_BUTTON6                     1006
#define IDC_BUTTON7                     1007
#define IDC_BUTTON8                     1008
#define IDC_BUTTON9                     1009
#define IDC_BUTTON10                    1010
#define IDC_BUTTON11                    1011
#define IDC_BUTTON12                    1012
#define IDC_BUTTON13                    1013
#define IDC_BUTTON14                    1014
#define IDC_BUTTON15                    1015
#define IDC_BUTTON16                    1016
#define IDC_BUTTON17                    1017
#define IDC_BUTTON18                    1018
#define IDC_BUTTON19                    1019
#define IDC_BUTTON20                    1020
#define IDC_BUTTON21                    1021
#define IDC_BUTTON22                    1022
#define IDC_BUTTON23                    1025
#define IDC_BUTTON24                    1026
#define IDC_BUTTON25                    1027
#define IDC_BUTTON26                    1028
#define IDC_BUTTON27                    1029
#define IDC_BUTTON28                    1031
#define IDC_BUTTON29                    1032
#define IDC_BUTTON30                    1033
#define IDC_BUTTON31                    1034
#define IDC_BUTTON32                    1035

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
