
include the INC file to use Zprotect macros in Pascal applications
Zprotect SDK supports Delphi/Free Pascal/Lazarus.

