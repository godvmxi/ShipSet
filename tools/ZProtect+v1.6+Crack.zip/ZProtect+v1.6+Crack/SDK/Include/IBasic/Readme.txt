include the INC file to use Zprotect macros in IBasic applications
