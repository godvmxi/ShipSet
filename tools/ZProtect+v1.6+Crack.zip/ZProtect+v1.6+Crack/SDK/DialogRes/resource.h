//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by DialogRes_zh-CN.rc
//
#define IDD_DIALOG1                     103
#define IDC_EDIT1                       1003
#define IDC_EDIT2                       1004
#define IDC_CHECK1                      1005
#define IDC_CHECK2                      1007
#define IDC_STC_NAME                    9000
#define IDD_PECANCER_REG                9001
#define IDC_EDT_SN                      9002
#define IDC_EDT_CODE                    9003
#define IDC_BTN_TRY                     9004
#define IDC_EDT_NAME                    9005
#define IDC_BTN_BUY                     9006
#define IDC_STC_CODE                    9007
#define IDC_STC_SN                      9008
#define IDC_EDT_PWD                     9009
#define IDD_PECANCER_PWD                9010
#define IDD_DIALOG_EXCEPTION            9011
#define IDC_EDT_EXCEPTION               9012
#define IDC_BTN_COPY                    9013
#define IDD_DIALOG_LOGIN                9014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        104
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
