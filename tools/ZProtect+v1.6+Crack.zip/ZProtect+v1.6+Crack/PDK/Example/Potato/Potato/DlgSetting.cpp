// DlgSetting.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "Potato.h"
#include "DlgSetting.h"


// CDlgSetting �Ի���

IMPLEMENT_DYNAMIC(CDlgSetting, CDialog)

CDlgSetting::CDlgSetting(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgSetting::IDD, pParent)
{

}

CDlgSetting::~CDlgSetting()
{
}

void CDlgSetting::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlgSetting, CDialog)
END_MESSAGE_MAP()


// CDlgSetting ��Ϣ��������
